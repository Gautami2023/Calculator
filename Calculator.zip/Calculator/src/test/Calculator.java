package test;
import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;

public class Calculator implements ActionListener{
    
    double num1=0,num2=0,result=0;
    int calculation;
    
     JFrame jf=new JFrame("Calculator");
     JLabel label=new JLabel();
     JTextField textfield=new JTextField();
     JRadioButton rb1=new JRadioButton("ON");
     JRadioButton rb2=new JRadioButton("OFF");
     JButton buttonzero=new JButton("0");
     JButton buttonone=new JButton("1");
     JButton buttontwo=new JButton("2");
     JButton buttonthree=new JButton("3");
     JButton buttonfour=new JButton("4");
     JButton buttonfive=new JButton("5");
     JButton buttonsix=new JButton("6");
     JButton buttonseven=new JButton("7");
     JButton buttoneight=new JButton("8");
     JButton buttonnine=new JButton("9");
     JButton buttondot=new JButton(".");
     JButton buttonclear=new JButton("C");
     JButton buttondelete=new JButton("DEL");
     JButton buttonequal=new JButton("=");
     JButton buttonmul=new JButton("X");
     JButton buttondiv=new JButton("/");
     JButton buttonplus=new JButton("+");
     JButton buttonminus=new JButton("-");
     JButton buttonSquare=new JButton("x\u00B2");
     JButton buttonReciprocal=new JButton("1/x");
     JButton buttonSqrt=new JButton("\u221A");
     
        
      
     
public Calculator(){
    PrepareGUI();
    addComponents();
    addActionEvent();
}
public void PrepareGUI(){
    jf.setSize(305,510);
    jf.getContentPane().setLayout(null);
    jf.getContentPane().setBackground(Color.BLACK);
    jf.setLocationRelativeTo(null);
    jf.setVisible(true);
    jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
}
public void addComponents(){
    label.setBounds(250,0,50,50);
    label.setForeground(Color.WHITE);
    jf.add(label);
    
    textfield.setBounds(10,40, 270, 40);
    textfield.setFont(new Font("Arial",Font.BOLD,20));
    textfield.setEditable(false);
    textfield.setHorizontalAlignment(SwingConstants.RIGHT);
    jf.add(textfield);
    
    rb1.setBounds(10, 95, 60, 40);
    rb1.setSelected(true);
    rb1.setFont(new Font("Arial",Font.BOLD,14));
    rb1.setBackground(Color.black);
    rb1.setForeground(Color.white);
    rb1.setFocusable(false);
    jf.add(rb1);
    
    rb2.setBounds(10, 120, 60, 40);
    rb2.setSelected(false);
    rb2.setFont(new Font("Arial",Font.BOLD,14));
    rb2.setBackground(Color.black);
    rb2.setForeground(Color.white);
    rb2.setFocusable(false);
    jf.add(rb2);
    
    ButtonGroup buttongroup=new ButtonGroup();
    buttongroup.add(rb1);
    buttongroup.add(rb2);
    
    buttonseven.setBounds(10, 230, 60, 40);
    buttonseven.setFont(new Font("Arial",Font.BOLD,20));
    buttonseven.setFocusable(false);
    jf.add(buttonseven);
    
    buttoneight.setBounds(80, 230, 60, 40);
    buttoneight.setFont(new Font("Arial",Font.BOLD,20));
    buttoneight.setFocusable(false);
    jf.add(buttoneight);
    
    buttonnine.setBounds(150, 230, 60, 40);
    buttonnine.setFont(new Font("Arial",Font.BOLD,20));
    buttonnine.setFocusable(false);
    jf.add(buttonnine);
    
    buttonfour.setBounds(10, 290, 60, 40);
    buttonfour.setFont(new Font("Arial",Font.BOLD,20));
    buttonfour.setFocusable(false);
    jf.add(buttonfour);
    
    buttonfive.setBounds(80, 290, 60, 40);
    buttonfive.setFont(new Font("Arial",Font.BOLD,20));
    buttonfive.setFocusable(false);
    jf.add(buttonfive);
    
    buttonsix.setBounds(150, 290, 60, 40);
    buttonsix.setFont(new Font("Arial",Font.BOLD,20));
    buttonsix.setFocusable(false);
    jf.add(buttonsix);
    
    buttonone.setBounds(10, 350, 60, 40);
    buttonone.setFont(new Font("Arial",Font.BOLD,20));
    buttonone.setFocusable(false);
    jf.add(buttonone);
    
    buttontwo.setBounds(80, 350, 60, 40);
    buttontwo.setFont(new Font("Arial",Font.BOLD,20));
    buttontwo.setFocusable(false);
    jf.add(buttontwo);
    
    buttonthree.setBounds(150, 350, 60, 40);
    buttonthree.setFont(new Font("Arial",Font.BOLD,20));
    buttonthree.setFocusable(false);
    jf.add(buttonthree);
    
    buttondot.setBounds(150, 410, 60, 40);
    buttondot.setFont(new Font("Arial",Font.BOLD,20));
    buttondot.setFocusable(false);
    jf.add(buttondot);
    
    buttonzero.setBounds(10, 410, 130, 40);
    buttonzero.setFont(new Font("Arial",Font.BOLD,20));
    buttonzero.setFocusable(false);
    jf.add(buttonzero);
    
    buttonequal.setBounds(220, 350, 60, 100);
    buttonequal.setFont(new Font("Arial",Font.BOLD,20));
    buttonequal.setFocusable(false);
    buttonequal.setBackground(new Color(239,188,2));
    jf.add(buttonequal);
    
    buttondiv.setBounds(220, 110, 60, 40);
    buttondiv.setFont(new Font("Arial",Font.BOLD,20));
    buttondiv.setFocusable(false);
    buttondiv.setBackground(new Color(239,188,2));
    jf.add(buttondiv);
    
    buttonSqrt.setBounds(10, 170, 60, 40);
    buttonSqrt.setFont(new Font("Arial",Font.BOLD,20));
    buttonSqrt.setFocusable(false);
    jf.add(buttonSqrt);
    
    buttonmul.setBounds(220, 230, 60, 100);
    buttonmul.setFont(new Font("Arial",Font.BOLD,20));
    buttonmul.setFocusable(false);
    buttonmul.setBackground(new Color(239,188,2));
    jf.add(buttonmul);
    
    buttonminus.setBounds(220, 170, 60, 100);
    buttonminus.setFont(new Font("Arial",Font.BOLD,20));
    buttonminus.setFocusable(false);
    buttonminus.setBackground(new Color(239,188,2));
    jf.add(buttonminus);
    
    buttonplus.setBounds(220, 290, 60, 100);
    buttonplus.setFont(new Font("Arial",Font.BOLD,20));
    buttonplus.setFocusable(false);
    buttonplus.setBackground(new Color(239,188,2));
    jf.add(buttonplus);
    
    buttonSquare.setBounds(80, 170, 60, 40);
    buttonSquare.setFont(new Font("Arial",Font.BOLD,20));
    buttonSquare.setFocusable(false);
    buttonSquare.setBackground(new Color(239,188,2));
    jf.add(buttonSquare);
    
    buttonReciprocal.setBounds(150,170,60,40);
    buttonReciprocal.setFont(new Font("Arial",Font.BOLD,20));
    buttonReciprocal.setFocusable(false);
    jf.add(buttonReciprocal);
    
    buttondelete.setBounds(150, 110, 60, 40);
    buttondelete.setFont(new Font("Arial",Font.BOLD,11));
    buttondelete.setFocusable(false);
    buttondelete.setBackground(Color.red);
    buttondelete.setForeground(Color.white);
    jf.add(buttondelete);
    
    buttonclear.setBounds(80, 110, 60, 40);
    buttonclear.setFont(new Font("Arial",Font.BOLD,20));
    buttonclear.setFocusable(false);
    buttonclear.setBackground(Color.red);
    buttonclear.setForeground(Color.white);
    jf.add(buttonclear);
    
}

public void addActionEvent(){
    rb1.addActionListener(this);
    rb2.addActionListener(this);
    buttonclear.addActionListener(this);
    buttondelete.addActionListener(this);
    buttondiv.addActionListener(this);
    buttonSqrt.addActionListener(this);
    buttonSquare.addActionListener(this);
    buttonReciprocal.addActionListener(this);
    buttonminus.addActionListener(this);
    buttonseven.addActionListener(this);
    buttoneight.addActionListener(this);
    buttonnine.addActionListener(this);
    buttonmul.addActionListener(this);
    buttonfour.addActionListener(this);
    buttonfive.addActionListener(this);
    buttonsix.addActionListener(this);
    buttonplus.addActionListener(this);
    buttonone.addActionListener(this);
    buttontwo.addActionListener(this);
    buttonthree.addActionListener(this);
    buttonequal.addActionListener(this);
    buttonzero.addActionListener(this);
    buttondot.addActionListener(this);
}
    
    public static void main(String[] args) {
        Calculator c=new Calculator();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source=e.getSource();
        
        if(source==rb1){
            enable();
        }
        else if(source==rb2){
            disable();
        }
        else if(source==buttonclear){
        label.setText("");
        textfield.setText("");
        }
        else if(source ==buttondelete){
        int length=textfield.getText().length();
        int number=length-1;
        if(length>0){
        StringBuilder back=new StringBuilder(textfield.getText());
        back.deleteCharAt(number);
        textfield.setText(back.toString());
        }if(textfield.getText().endsWith(""));
        label.setText("");
        }
        else if(source==buttonzero){
            if(textfield.getText().equals("0")){
            return;}
            else{
                    textfield.setText(textfield.getText()+ "0");
                    }
        }
        else if(source==buttonone){
                textfield.setText(textfield.getText()+"1");
        }
        else if(source==buttontwo){
                textfield.setText(textfield.getText()+"2");
        }
        else if(source==buttonthree){
                textfield.setText(textfield.getText()+"3");
        }
        else if(source==buttonfour){
                textfield.setText(textfield.getText()+"4");
        }
        else if(source==buttonfive){
                textfield.setText(textfield.getText()+"5");
        }
        else if(source==buttonsix){
                textfield.setText(textfield.getText()+"6");
        }
        else if(source==buttonseven){
                textfield.setText(textfield.getText()+"7");
        }
        else if(source==buttoneight){
                textfield.setText(textfield.getText()+"8");
        }
        else if(source==buttonnine){
                textfield.setText(textfield.getText()+"9");
        }
        else if(source==buttondot){
               if(textfield.getText().contains(".")){
               return;}
               else{
                       textfield.setText(textfield.getText()+".");}
        }
        else if(source==buttonplus){
                String str=textfield.getText();
                num1=Double.parseDouble(textfield.getText());
                calculation=1;
                textfield.setText("");
                label.setText(str+"+");
        }
         else if(source==buttonminus){
                String str=textfield.getText();
                num1=Double.parseDouble(textfield.getText());
                calculation=2;
                textfield.setText("");
                label.setText(str+"-");
        }
         else if(source==buttonmul){
                String str=textfield.getText();
                num1=Double.parseDouble(textfield.getText());
                calculation=3;
                textfield.setText("");
                label.setText(str+"*");
        }
         else if(source==buttondiv){
                String str=textfield.getText();
                num1=Double.parseDouble(textfield.getText());
                calculation=4;
                textfield.setText("");
                label.setText(str+"/");
        }
         else if(source==buttonSquare){
         num1=Double.parseDouble(textfield.getText());
         double square=Math.pow(num1, 2);
         String string=Double.toString(square);
         if(string.endsWith(".0")){
             textfield.setText(string.replace(".0", ""));
         }
         else{
         textfield.setText(string);}}
        
         else if(source==buttonSqrt){
             num1=Double.parseDouble(textfield.getText());
             double sqrt=Math.sqrt(num1);
             textfield.setText(Double.toString(sqrt));
         }
         else if(source==buttonReciprocal){
         num1=Double.parseDouble(textfield.getText());
         double reciprocal=1/num1;
         String string=Double.toString(reciprocal);
         if(string.endsWith(".0")){
             textfield.setText(string.replace(".0", ""));
         }else{
              textfield.setText(string);
         }
         }
         else if(source==buttonequal){
         num2=Double.parseDouble(textfield.getText());
         switch(calculation){
             case 1: result =num1 +num2;
             break;
             case 2: result =num1 -num2; 
             break;
             case 3: result =num1 *num2; 
             break;
             case 4: result =num1 /num2; 
             break;
         }
         if(Double.toString(result).endsWith(".0")){
             textfield.setText(Double.toString(result).replace(".0",""));
         }else{
         textfield.setText(Double.toString(result));
         }
         label.setText("");
         num1=result;
      }
    }
    public void enable(){
        rb1.setEnabled(false);
        rb2.setEnabled(true);
        textfield.setEditable(true);
        label.setEnabled(true);
        buttonclear.setEnabled(true);
        buttondelete.setEnabled(true);
        buttondiv.setEnabled(true);
        buttonSqrt.setEnabled(true);
        buttonSquare.setEnabled(true);
        buttonReciprocal.setEnabled(true);
        buttonminus.setEnabled(true);
        buttonseven.setEnabled(true);
        buttoneight.setEnabled(true);
        buttonnine.setEnabled(true);
        buttonmul.setEnabled(true);
        buttonfour.setEnabled(true);
        buttonfive.setEnabled(true);
        buttonsix.setEnabled(true);
        buttonplus.setEnabled(true);
        buttonone.setEnabled(true);
        buttontwo.setEnabled(true);
        buttonthree.setEnabled(true);
        buttonequal.setEnabled(true);
        buttonzero.setEnabled(true);
        buttondot.setEnabled(true);
        
        
    }
    public void disable(){
        rb1.setEnabled(true);
        rb2.setEnabled(false);
        textfield.setEditable(false);
        label.setEnabled(false);
        label.setText("");
        textfield.setText("");
        buttonclear.setEnabled(false);
        buttondelete.setEnabled(false);
        buttondiv.setEnabled(false);
        buttonSqrt.setEnabled(false);
        buttonSquare.setEnabled(false);
        buttonReciprocal.setEnabled(false);
        buttonminus.setEnabled(false);
        buttonseven.setEnabled(false);
        buttoneight.setEnabled(false);
        buttonnine.setEnabled(false);
        buttonmul.setEnabled(false);
        buttonfour.setEnabled(false);
        buttonfive.setEnabled(false);
        buttonsix.setEnabled(false);
        buttonplus.setEnabled(false);
        buttonone.setEnabled(false);
        buttontwo.setEnabled(false);
        buttonthree.setEnabled(false);
        buttonequal.setEnabled(false);
        buttonzero.setEnabled(false);
        buttondot.setEnabled(false);
        
    }
    
}
